#include "swtor_parser.h"
#include <iostream>
#include <string>

int main() {
    // Test parsing a line with a companion
    std::string line = "[09:12:46.505] [@Pugzeronine#688451045458733/Z0-0M {3841216886079488}:6168012297889|(3467.92,114.66,399.94,0.00)|(53118/53118)] [=] [ {4196681264398336}] [RemoveEffect {836045448945478}: Lucky Shots {4196681264398653}]";
    
    swtor::CombatLine parsed{};
    auto status = swtor::parse_combat_line(line, parsed);
    
    if (status != swtor::ParseStatus::Ok) {
        std::cout << "✗ Failed to parse line\n";
        return 1;
    }
    
    // Check if companion was detected
    if (!parsed.source.is_companion) {
        std::cout << "✗ Companion not detected\n";
        return 1;
    }
    
    std::cout << "Source entity details:\n";
    std::cout << "  is_companion: " << parsed.source.is_companion << "\n";
    std::cout << "  is_player: " << parsed.source.is_player << "\n";
    std::cout << "  name: '" << parsed.source.name << "'\n";
    std::cout << "  companion_name: '" << parsed.source.companion_name << "'\n";
    std::cout << "  display: '" << parsed.source.display << "'\n";
    std::cout << "\nOwner details:\n";
    std::cout << "  has_owner: " << parsed.source.owner.has_owner << "\n";
    std::cout << "  owner name_no_at: '" << parsed.source.owner.name_no_at << "'\n";
    std::cout << "  owner player_numeric_id: " << parsed.source.owner.player_numeric_id << "\n";
    
    std::cout << "\nExpected:\n";
    std::cout << "  Companion name: 'Z0-0M'\n";
    std::cout << "  Owner name: 'Pugzeronine'\n";
    std::cout << "  Owner ID: 688451045458733\n";
    
    // Check companion name
    if (parsed.source.name == "Z0-0M") {
        std::cout << "\n✓ Companion name correct!\n";
    } else {
        std::cout << "\n✗ Companion name wrong! Got: '" << parsed.source.name << "'\n";
    }
    
    // Check owner name
    if (parsed.source.owner.name_no_at == "Pugzeronine") {
        std::cout << "✓ Owner name correct!\n";
    } else {
        std::cout << "✗ Owner name wrong! Got: '" << parsed.source.owner.name_no_at << "'\n";
    }
    
    // Check owner ID
    if (parsed.source.owner.player_numeric_id == 688451045458733ULL) {
        std::cout << "✓ Owner ID correct!\n";
    } else {
        std::cout << "✗ Owner ID wrong! Got: " << parsed.source.owner.player_numeric_id << "\n";
    }
    
    return 0;
}
