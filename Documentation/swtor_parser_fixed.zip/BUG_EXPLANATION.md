# Bug Found in SWTOR Parser

## The Problem

In `swtor_parser.cpp` at line 251, when parsing a companion entity, the code incorrectly initializes the `CompanionOwner` structure:

```cpp
out.owner = { owner_name, owner_id, owner_is_player };
```

## The Issue

The `CompanionOwner` struct has three fields:
```cpp
struct CompanionOwner {
    std::string_view name_no_at{};     // Field 1
    uint64_t player_numeric_id{ 0 };   // Field 2
    bool has_owner{ false };           // Field 3  <-- PROBLEM HERE
};
```

The initialization is passing:
1. `owner_name` → correctly goes to `name_no_at` ✓
2. `owner_id` → correctly goes to `player_numeric_id` ✓  
3. `owner_is_player` → goes to `has_owner` ✗ **WRONG!**

## What's Wrong

- `owner_is_player` is a boolean that indicates whether the owner token LOOKED like a player (had an @ prefix)
- `has_owner` should indicate whether this companion HAS an owner

These are semantically different:
- `owner_is_player` = "does the owner string start with @?"
- `has_owner` = "does this companion have an owner entity?"

## The Fix

Line 251 should be:
```cpp
out.owner = { owner_name, owner_id, true };
```

Because if we're in the companion parsing branch (inside the `if (slash != std::string_view::npos)` block), we DEFINITELY have an owner (that's what the slash separates).

The `has_owner` field should always be `true` in this context, not dependent on whether the owner token starts with @.

## Why It Might Not Have Been Noticed

In practice, companion owners are almost always players (starting with @), so `owner_is_player` is usually true anyway. But:
1. It's semantically incorrect
2. If there's ever an edge case where a companion owner doesn't start with @, `has_owner` would be wrongly set to false
3. The code is confusing because it uses the wrong variable for the wrong purpose
