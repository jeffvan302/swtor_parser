#include "swtor_parser.h"
#include <iostream>
#include <string>

int main() {
    // Test the EventPred::matches function that was missing
    swtor::CombatLine line{};
    line.evt.kind = swtor::EventKind::ApplyEffect;
    line.evt.effect.name = "Damage";
    line.evt.effect.id = 836045448945501ULL;
    
    // Test with EventPred
    auto damage_pred = swtor::Evt::Damage;
    if (damage_pred == line) {
        std::cout << "✓ EventPred::matches works correctly!\n";
    } else {
        std::cout << "✗ EventPred::matches failed\n";
        return 1;
    }
    
    // Test with kind matching
    auto apply_pred = swtor::Evt::ApplyEffect;
    if (apply_pred == line) {
        std::cout << "✓ Kind matching works!\n";
    } else {
        std::cout << "✗ Kind matching failed\n";
        return 1;
    }
    
    // Test OR combination
    auto damage_or_heal = swtor::Evt::Damage | swtor::Evt::Heal;
    if (damage_or_heal == line) {
        std::cout << "✓ OR combination works!\n";
    } else {
        std::cout << "✗ OR combination failed\n";
        return 1;
    }
    
    std::cout << "\nAll tests passed! The linker error is fixed.\n";
    return 0;
}
