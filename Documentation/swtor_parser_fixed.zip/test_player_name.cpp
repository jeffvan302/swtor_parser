#include "swtor_parser.h"
#include <iostream>
#include <string>

int main() {
    // Test parsing a real combat log line with a player
    std::string line = "[09:11:48.410] [@Pugzeronine#688451045458733|(9.82,9.25,16.52,2.92)|(1/420747)] [] [] [AreaEntered {836045448953664}: Defender {137438988839}] (he3001) <v7.0.0b>";
    
    swtor::CombatLine parsed{};
    auto status = swtor::parse_combat_line(line, parsed);
    
    if (status != swtor::ParseStatus::Ok) {
        std::cout << "✗ Failed to parse line\n";
        return 1;
    }
    
    // Check if player was detected
    if (!parsed.source.is_player) {
        std::cout << "✗ Player not detected\n";
        return 1;
    }
    
    // Print the parsed name
    std::cout << "Parsed player name: '" << parsed.source.name << "'\n";
    std::cout << "Display field: '" << parsed.source.display << "'\n";
    std::cout << "Expected name: 'Pugzeronine'\n";
    
    // Check if the name is correct
    if (parsed.source.name == "Pugzeronine") {
        std::cout << "✓ Player name parsed correctly!\n";
    } else {
        std::cout << "✗ Player name is WRONG!\n";
        std::cout << "  Got: '" << parsed.source.name << "'\n";
        return 1;
    }
    
    // Check the numeric ID
    std::cout << "Player ID: " << parsed.source.id.hi << "\n";
    std::cout << "Expected ID: 688451045458733\n";
    
    if (parsed.source.id.hi == 688451045458733ULL) {
        std::cout << "✓ Player ID parsed correctly!\n";
    } else {
        std::cout << "✗ Player ID is wrong!\n";
        return 1;
    }
    
    std::cout << "\n✓ All player name tests passed!\n";
    return 0;
}
